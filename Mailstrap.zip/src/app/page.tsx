import Home from "@/modules/home/home";

const Page = () => {
  return (
    <div>
      <Home /> 
    </div>
  );
};

export default Page;
