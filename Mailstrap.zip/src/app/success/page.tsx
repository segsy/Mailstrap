import React from 'react'

const Page = () => {
  return (
    <div className='w-full h-screen grid place-items-center'>
        <h5>Congratulation you subscribed successfully!</h5>
    </div>
  )
}

export default Page