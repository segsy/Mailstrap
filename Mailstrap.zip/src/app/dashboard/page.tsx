import Dashboard from "@/modules/dashboard";

const Page = () => {
  return (
      <Dashboard />
  );
};

export default Page;
