import Write from '@/modules/dashboard/elements/write/write'

const Page = () => {
  return (
   <Write />
  )
}

export default Page