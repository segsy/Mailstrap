import Main from "./elements/main/main";

const Dashboard = () => {
  return (
      <Main />
  );
};

export default Dashboard;
